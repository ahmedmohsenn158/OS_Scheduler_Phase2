#pragma once

typedef struct processData
{
    int arrivaltime;
    int priority;
    int runningtime;
    int id;
}processData ; 
